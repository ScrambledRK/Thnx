package at.dotpoint.tanx;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import haxe.at.dotpoint.math.DistanceMethod;
import haxe.at.dotpoint.math.Trigonometry;
import haxe.at.dotpoint.math.vector.IVector2;
import haxe.at.dotpoint.math.vector.IVector3;
import haxe.at.dotpoint.math.vector.Vector2;
import haxe.lang.VarArgsBase;
import haxe.thnx.model.World;
import haxe.thnx.model.entities.PowerupEntity;
import haxe.thnx.model.entities.TankEntity;
import haxe.thnx.model.entities.WorldEntity;
import haxe.thnx.model.enums.Alliance;
import haxe.thnx.model.enums.PowerupType;
import haxe.thnx.model.tileset.Tile;
import at.dotpoint.tanx.client.ThnxClient;


public class Main
{	

	
	/**
	 * 
	 */
	public static ThnxClient client;
	
	/**
	 * 
	 */
	public static Timer timer;
	
	// ************************************************************************ //
	// Constructor
	// ************************************************************************ //
	
	/**
	 * 
	 * @param args
	 */
	public static void main( String[] args )
	{
		String levelURL =  "res/level_definition.json";
		InetSocketAddress address = new InetSocketAddress( 9998 );
		
		// -------------- //
		
		CustomViewController 	viewController = new CustomViewController();
								viewController.initialize( new Vector2( 520, 545 ), null );
								
		Main.client = new ThnxClient();
		
		Main.client.setViewController( viewController );
		Main.client.initialize( levelURL, address, false );
		
		Main.startSimulation();
	}	

	
	// ************************************************************************ //
	// Init
	// ************************************************************************ //
	
	/**
	 * 
	 */
	private static void startSimulation()
	{		
		// move, shoot, target
		// Main.client.enableConsoleCommands();
		
		Main.timer = new Timer();
		Main.timer.schedule( new GameLoop(), 0, 1000 / 30 );
	}
	
}

/**
 * 
 */
class GameLoop extends TimerTask
{
	
	
	@Override
	public void run()
	{
		if( !Main.client.isConnected() )
			return;		
	}
	
	
}
