package at.dotpoint.tanx.client;

import haxe.thnx.event.SocketEvent;

public abstract class ThnxListener
{
	abstract public void onMessage( SocketEvent event );
}
