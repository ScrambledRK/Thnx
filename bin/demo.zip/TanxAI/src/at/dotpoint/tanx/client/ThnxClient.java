package at.dotpoint.tanx.client;

import java.net.InetSocketAddress;

import at.dotpoint.tanx.Main;
import haxe.at.dotpoint.core.dispatcher.event.IEventDispatcher;
import haxe.lang.Closure;
import haxe.lang.Function;
import haxe.thnx.event.SocketEvent;
import haxe.thnx.model.Lobby;
import haxe.thnx.model.World;
import haxe.thnx.model.entities.TankEntity;
import haxe.thnx.socket.IClientSocket;
import haxe.thnx.view.IViewController;
import javahx.thnx.ThnxMain;

/**
 * 
 */
public class ThnxClient
{
	
	/**
	 * 
	 */
	private ThnxMain client; 
	
	// ************************************************************************ //
	// Constructor
	// ************************************************************************ //
	
	/**
	 * 
	 */
	public ThnxClient()
	{			
		this.client = ThnxMain.instance = new ThnxMain( (IEventDispatcher)null );
	}
	
	// ************************************************************************ //
	// getter / setter
	// ************************************************************************ //	
	
	/**
	 * 
	 * @return
	 */
	public IClientSocket getClientSocket()
	{
		return this.client.socket;
	}
	
	/**
	 * 
	 * @return
	 */
	public void setClientSocket( IClientSocket socket )
	{
		this.client.socket = socket;
	}
	
	/**
	 * 
	 * @return
	 */
	public IViewController getViewController()
	{
		return this.client.view;
	}
	
	/**
	 * 
	 * @return
	 */
	public void setViewController( IViewController viewController )
	{
		this.client.view = viewController;
	}
	
	/**
	 * 
	 * @return
	 */
	public World getWorldModel()
	{
		return this.client.world;
	}
	
	/**
	 * 
	 * @return
	 */
	public void setWorldModel( World world )
	{
		this.client.world = world;
	}
	
	/**
	 * 
	 * @return
	 */
	public Lobby getLobbyModel()
	{
		return this.client.lobby;
	}
	
	/**
	 * 
	 * @return
	 */
	public void setLobbyModel( Lobby lobby )
	{
		this.client.lobby = lobby;
	}
	
	// ----------------------------------------------------------------------- //
	// ----------------------------------------------------------------------- //
	
	/**
	 * 
	 * @return
	 */
	public boolean isConnected()
	{		
		if( Main.client.getLobbyModel().player == null )
			return false;
		
		if( Main.client.getLobbyModel().player.getTank() == null )			
			return false;
		
		return true;
	}
	
	/**
	 * 
	 * @return
	 */
	public TankEntity getPlayerTank()
	{
		return this.getLobbyModel().player.getTank();
	}
	
	// ************************************************************************ //
	// Initialize
	// ************************************************************************ //
	
	/**
	 * 
	 */
	public void initialize()
	{
		this.initialize( null, null, true );
	}
	
	/**
	 * 
	 */
	public void initialize( String levelURL )
	{
		this.initialize( levelURL, new InetSocketAddress( 9998 ), true );
	}
	
	/**
	 * 
	 */
	public void initialize( String levelURL, InetSocketAddress address )
	{
		this.initialize( levelURL, address, true );
	}
	
	/**
	 * 
	 */	
	public void initialize( String levelURL, InetSocketAddress address, boolean useDefaultView )
	{
		if( useDefaultView )
			this.initView();
		
		if( levelURL != null )
			this.initModel( levelURL );
		
		if( address != null )
			this.initServer( address );		
	}
	
	// -------------------------------------------------------------------------- //
	// -------------------------------------------------------------------------- //
	
	/**
	 * 
	 */
	protected void initView()
	{
		this.client.initView();
	}
	
	/**
	 * 
	 */
	protected void initModel( String levelURL )
	{
		this.client.initModel( levelURL );
	}
	
	/**
	 * 
	 */
	protected void initServer( InetSocketAddress address )
	{
		this.startServer( new DefaultListener(this), address );
	}
	
	// -------------------------------------------------------------------------- //
	// -------------------------------------------------------------------------- //
	
	/**
	 * 
	 */
	public void startServer( ThnxListener listener, InetSocketAddress address )
	{
		this.client.addListener( SocketEvent.MESSAGE_RECIEVED, ((Function)(new Closure( listener, "onMessage" ))) );
		this.client.startServer( address );
	}
	
	/**
	 * 
	 */
	public void respondeToMessage( SocketEvent event )
	{
		this.client.respondeToMessage( event.data );
	}	
	
	// -------------------------------------------------------------------------- //
	// -------------------------------------------------------------------------- //
	
	/**
	 * 
	 */
	public void enableConsoleCommands()
	{
		this.client.startConsoleCommands();
	}
}

/**
 * 
 */
class DefaultListener extends ThnxListener
{
	/**
	 * 
	 */
	private ThnxClient client; 
	
	/**
	 * 
	 * @param client
	 */
	public DefaultListener( ThnxClient client )
	{
		this.client = client;
	}

	@Override
	public void onMessage( SocketEvent event )
	{
		this.client.respondeToMessage( event );
		
		if( this.client.getViewController() != null )
			this.client.getViewController().update();
	}
}