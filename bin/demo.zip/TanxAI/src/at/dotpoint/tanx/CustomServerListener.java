package at.dotpoint.tanx;

import haxe.thnx.event.SocketEvent;
import at.dotpoint.tanx.client.ThnxListener;

public class CustomServerListener extends ThnxListener
{
	
	/**
	 * 
	 */
	public CustomServerListener()
	{
		
	}
	
	/**
	 * 
	 * @param event
	 */
	@Override
	public void onMessage( SocketEvent event )
	{
		return;
	}
}