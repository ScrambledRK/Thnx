package at.dotpoint.tanx;

import java.awt.Color;

import haxe.at.dotpoint.math.vector.IVector2;
import javahx.thnx.view.ViewController;

public class CustomViewController extends ViewController
{
	
	/**
	 * 
	 */
	public CustomViewController()
	{
		super();
	}
	
	/**
	 * 
	 */
	@Override
	public void update()
	{
		super.update();		
	}
}
