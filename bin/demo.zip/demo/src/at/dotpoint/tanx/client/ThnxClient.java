package at.dotpoint.tanx.client;

import at.dotpoint.tanx.Main;
import haxe.at.dotpoint.core.dispatcher.event.IEventDispatcher;
import haxe.lang.Closure;
import haxe.lang.Function;
import haxe.thnx.event.SocketEvent;
import haxe.thnx.model.Lobby;
import haxe.thnx.model.World;
import haxe.thnx.model.entities.TankEntity;
import haxe.thnx.socket.IClientSocket;
import haxe.thnx.view.IViewController;
import javahx.thnx.ThnxMain;

/**
 * 
 */
public class ThnxClient
{
	
	/**
	 * 
	 */
	private ThnxMain client; 
	
	/**
	 * 
	 */
	private String levelURL = "level_definition.json";
	
	/**
	 * 
	 */
	private boolean isConnected;
	
	// ************************************************************************ //
	// Constructor
	// ************************************************************************ //
	
	/**
	 * 
	 */
	public ThnxClient()
	{			
		this.client = ThnxMain.instance = new ThnxMain( (IEventDispatcher)null );
	}
	
	// ************************************************************************ //
	// getter / setter
	// ************************************************************************ //	
	
	/**
	 * 
	 * @return
	 */
	public IClientSocket getClientSocket()
	{
		return this.client.socket;
	}
	
	/**
	 * 
	 * @return
	 */
	public IViewController getViewController()
	{
		return this.client.view;
	}
	
	/**
	 * 
	 * @return
	 */
	public World getWorldModel()
	{
		return this.client.world;
	}
	
	/**
	 * 
	 * @return
	 */
	public Lobby getLobbyModel()
	{
		return this.client.lobby;
	}
	
	// ----------------------------------------------------------------------- //
	// ----------------------------------------------------------------------- //
	
	/**
	 * 
	 * @return
	 */
	public boolean isConnected()
	{
		if( !this.isConnected )
		{
			if( Main.client.getLobbyModel().player == null )
				return false;
			
			if( Main.client.getLobbyModel().player.getTank() == null )
				return false;
			
			this.isConnected = true;
		}		
		
		return this.isConnected;
	}
	
	/**
	 * 
	 * @return
	 */
	public TankEntity getPlayerTank()
	{
		return this.getLobbyModel().player.getTank();
	}
	
	// ************************************************************************ //
	// Initialize
	// ************************************************************************ //
	
	/**
	 * 
	 */
	public void initialize()
	{
		this.initialize( true, true, true );
	}
	
	/**
	 * 
	 */	
	public void initialize( boolean useDefaultView, boolean useDefaultModel, boolean useDefaultServer )
	{
		if( useDefaultView )
			this.initView();
		
		if( useDefaultModel )
			this.initModel();
		
		if( useDefaultServer )
			this.initServer();		
	}
	
	// -------------------------------------------------------------------------- //
	// -------------------------------------------------------------------------- //
	
	/**
	 * 
	 */
	protected void initView()
	{
		this.client.initView();
	}
	
	/**
	 * 
	 */
	protected void initModel()
	{
		this.client.initModel( this.levelURL );
	}
	
	/**
	 * 
	 */
	protected void initServer()
	{
		this.startServer( new DefaultListener(this) );
	}
	
	// -------------------------------------------------------------------------- //
	// -------------------------------------------------------------------------- //
	
	/**
	 * 
	 */
	public void startServer( ThnxListener listener )
	{
		this.client.addListener( SocketEvent.MESSAGE_RECIEVED, ((Function)(new Closure( listener, "onMessage" ))) );
		this.client.startServer();
	}
	
	/**
	 * 
	 */
	public void respondeToMessage( SocketEvent event )
	{
		this.client.respondeToMessage( event.data );
	}	

}

/**
 * 
 */
class DefaultListener extends ThnxListener
{
	/**
	 * 
	 */
	private ThnxClient client; 
	
	/**
	 * 
	 * @param client
	 */
	public DefaultListener( ThnxClient client )
	{
		this.client = client;
	}

	@Override
	public void onMessage( SocketEvent event )
	{
		this.client.respondeToMessage( event );
		
		if( this.client.getViewController() != null )
			this.client.getViewController().update();
	}
}