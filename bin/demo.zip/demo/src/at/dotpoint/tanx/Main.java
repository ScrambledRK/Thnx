package at.dotpoint.tanx;

import java.util.Timer;
import java.util.TimerTask;

import haxe.at.dotpoint.math.Trigonometry;
import haxe.at.dotpoint.math.vector.IVector3;
import haxe.at.dotpoint.math.vector.Vector2;
import haxe.lang.VarArgsBase;
import haxe.thnx.model.World;
import haxe.thnx.model.entities.TankEntity;
import haxe.thnx.model.enums.Alliance;
import at.dotpoint.tanx.client.ThnxClient;


public class Main
{	

	
	/**
	 * 
	 */
	public static ThnxClient client;
	
	/**
	 * 
	 */
	public static Timer timer;
	
	// ************************************************************************ //
	// Constructor
	// ************************************************************************ //
	
	/**
	 * 
	 * @param args
	 */
	public static void main( String[] args )
	{
		Main.client = new ThnxClient();
		Main.client.initialize();
		
		Main.startSimulation();
	}	

	
	// ************************************************************************ //
	// Init
	// ************************************************************************ //
	
	/**
	 * 
	 */
	private static void startSimulation()
	{
		Main.timer = new Timer();
		Main.timer.schedule( new GameLoop(), 0, 1000 / 30 );
	}	
}

/**
 * 
 */
class GameLoop extends TimerTask
{
	//
	private int numTicks = 0;
	
	
	// -------------------------------------------------------- //
	// -------------------------------------------------------- //
	
	@Override
	public void run()
	{
		if( !Main.client.isConnected() )
			return;
		
		// -------------- //
		
		TankEntity playerEntity = Main.client.getPlayerTank();		
		TankEntity closestEntity = this.getClosestEnemy( playerEntity );	
		
		if( closestEntity == null )
			return;
		
		if( this.numTicks++ > 30 )
		{
			this.moveToTank( playerEntity, closestEntity );
			this.numTicks = 0;
		}
		
		this.aimAtTank( playerEntity, closestEntity );	
		this.shootIfClose( playerEntity, closestEntity );
	}
	
	// -------------------------------------------------------- //
	// -------------------------------------------------------- //
	
	/**
	 * 
	 */
	private void moveToTank( TankEntity playerEntity, TankEntity tankEntity )
	{
		IVector3 tank_position = tankEntity.transform.get_position();		
		IVector3 player_position = playerEntity.transform.get_position();
		
		double x = tank_position.get_x() - player_position.get_x();
		double y = tank_position.get_y() - player_position.get_y();
	
		// ------------ //
	
		double t = 0;
	
		t = x * Math.sin(Math.PI * 0.75) - y * Math.cos(Math.PI * 0.75);
		y = y * Math.sin(Math.PI * 0.75) + x * Math.cos(Math.PI * 0.75);
		x = t;
	
		// ------------ //
	
		Main.client.getClientSocket().requestMove( x, y );
	}
	
	/**
	 * 
	 */
	private void aimAtTank( TankEntity playerEntity, TankEntity tankEntity )
	{
		IVector3 tank_position = tankEntity.transform.get_position();		
		IVector3 player_position = playerEntity.transform.get_position();
		
		double x = tank_position.get_x() - player_position.get_x();
		double y = tank_position.get_y() - player_position.get_y();
		
					
		double angle = Math.floor(Math.atan2( x, y ) / (Math.PI / 180));
		
		Main.client.getClientSocket().requestTarget( angle );
	}	
	
	/**
	 * 
	 */
	private void shootIfClose( TankEntity playerEntity, TankEntity tankEntity )
	{
		IVector3 tank_position = tankEntity.transform.get_position();		
		IVector3 player_position = playerEntity.transform.get_position();
		
		double distance = Trigonometry.calculateDistanceVector2( player_position, tank_position, null );
		
		if( playerEntity.cannon.isShooting )
		{
			if( distance > 4 )
				Main.client.getClientSocket().requestShoot( false );
		}
		else 
		{
			if( distance < 4 )
				Main.client.getClientSocket().requestShoot( true );			
		}
		
	}
	
	// -------------------------------------------------------- //
	// -------------------------------------------------------- //
	
	/**
	 * 
	 * @return
	 */
	private TankEntity getClosestEnemy( TankEntity playerEntity )
	{
		World worldModel = Main.client.getWorldModel();
		
		// --------------- //
		
		IVector3 player_position = playerEntity.transform.get_position();
		
		TankEntity closestEntity = null;
		double min_distance = Double.MAX_VALUE;
		
		for (int j = 0; j < worldModel.tanks.length; j++)
		{
			TankEntity tankEntity = worldModel.tanks.__get( j );
			
			if( tankEntity == playerEntity )
				continue;
			
			if( !tankEntity.status.isAlive() )
				continue;
				
			if( tankEntity.status.team == playerEntity.status.team )
				continue;
			
			// ----------- //
			
			IVector3 tank_position = tankEntity.transform.get_position();			
			double distance = Trigonometry.calculateDistanceVector2( player_position, tank_position, null ); 
			
			if( distance < min_distance )
			{
				min_distance = distance;
				closestEntity = tankEntity;
			}
		}
		
		// -------------- //
		
		return closestEntity;
	}
	
}
